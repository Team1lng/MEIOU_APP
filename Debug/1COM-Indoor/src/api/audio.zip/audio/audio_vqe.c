/*
 * @Author: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
 * @Date: 2023-07-04 10:33:17
 * @LastEditors: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
 * @LastEditTime: 2023-11-30 16:59:29
 * @FilePath: /two-wire-indoor/src/api/audio/audio_vqe.c
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
#include "audio_vqe.h"
#include "ak_common_audio.h"
struct ak_audio_nr_attr user_ai_nr_attr = {-25, 0, 1};
struct ak_audio_agc_attr user_ai_agc_attr = {16384, 4, 0, 60, 0, 1};
struct ak_audio_aec_attr user_ai_aec_attr = {0, 1024, 1024, 0, 512, 1, 6553};
struct ak_audio_aslc_attr user_ai_aslc_attr = {32768, 9, 0};

/* set ao voice quality enhancement param */
struct ak_audio_nr_attr user_ao_nr_attr = {-25, 0, 1};
struct ak_audio_aslc_attr user_ao_aslc_attr = {22937, 10, 0};
/* gain */

int user_ai_gain = 3;

/*			### how to set ai gain ###
ak_ai_set_gain(ai_handle_id,user_ai_gain);*/

int user_ao_gain = 4;

/*			### how to set ao gain ###
ak_ao_set_gain(ao_handle_id,user_ao_gain);*/

struct ak_audio_eq_attr user_ai_eq_attr = {
    0,
    0,
    {2600, 63, 125, 250, 500, 1000, 2000, 4000, 8000, 16000},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {716, 717, 717, 717, 717, 717, 717, 717, 717, 717},
    {TYPE_LPF, TYPE_PF1, TYPE_PF1, TYPE_PF1, TYPE_PF1, TYPE_PF1, TYPE_PF1, TYPE_PF1, TYPE_PF1, TYPE_PF1},
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}};

struct ak_audio_eq_attr user_ao_eq_attr = {
    0,
    1,
    {850, 2900, 125, 250, 500, 1000, 2000, 4000, 8000, 16000},
    {-14336, -10240, 0, 0, 0, 0, 0, 0, 0, 0},
    {716, 1024, 717, 717, 717, 717, 717, 717, 717, 717},
    {TYPE_HPF, TYPE_PF1, TYPE_PF1, TYPE_PF1, TYPE_PF1, TYPE_PF1, TYPE_PF1, TYPE_PF1, TYPE_PF1, TYPE_PF1},
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0}};
