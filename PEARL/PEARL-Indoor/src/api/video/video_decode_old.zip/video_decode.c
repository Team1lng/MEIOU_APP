#include "video_decode.h"
#include "ak_thread.h"
#include "stdio.h"
#include "stdlib.h"
#include "time.h"
#include "unistd.h"
#include "queue.h"
#include "ak_mem.h"
#include "ak_vdec.h"
#include "string.h"
#include "leo_api.h"
#include "ring_buffer.h"

static int decode_src_width = 0;
static int decode_src_height = 0;

static bool video_decode_run = false;
static bool video_decode_thread_run = false;
static bool video_decode_ready = false;
static int video_decode_handle_id = -1;

static char video_decode_type = 0; // 0:h264 1:mjpeg 2:h265

static ak_mutex_t video_decode_mutex;
static ring_buffer video_decode_ring_buffer;

bool video_normal_falg = false;

bool video_decode_queue_reset(void);

static void video_decode_device_open(void)
{
	struct ak_vdec_param param;
	memset(&param, 0, sizeof(struct ak_vdec_param));
	param.vdec_type = video_decode_type == 1 ? MJPEG_ENC_TYPE : video_decode_type == 2 ? HEVC_ENC_TYPE
											   : H264_ENC_TYPE;
	param.output_type = AK_YUV420SP;
	param.sc_width = decode_src_width;
	param.sc_height = decode_src_height;
	param.stream_buf_size = 4 * 1024 * 1024;
	// 512 * 1024;
	param.frame_buf_num = 3; // 2;
	ak_vdec_open(&param, &video_decode_handle_id);
	ak_vdec_clear_buff(video_decode_handle_id);

	ring_buffer_init(&video_decode_ring_buffer, 4 * 1024 * 1024 /*  200 * 1024 */, &video_decode_mutex);
}

static void video_decode_device_close(void)
{

	if (video_decode_handle_id != -1)
	{

		ak_vdec_close(video_decode_handle_id);

		video_decode_handle_id = -1;
	}

	ring_buffer_release(&video_decode_ring_buffer);
}

static void video_data_stream_send(unsigned char *pdata, int len)
{
	int dec_len = 0;
	int read_len = len;
	int send_len = 0;

	while (read_len > 0)
	{
		ak_vdec_send_stream(video_decode_handle_id, &pdata[send_len], read_len, NONBLOCK, &dec_len);
		read_len -= dec_len;
		send_len += dec_len;
	}
}

// static bool snap = true;
static int frame_skip_count = 0;
void frame_skip_count_set(int count)
{
	frame_skip_count = count;
}

static void *video_decode_thread_task(void *arg)
{
	struct ak_vdec_frame frame = {0};

	int count = 0;
	while (1)
	{
		memset(&frame, 0, sizeof(struct ak_vdec_frame));
		if (ak_vdec_get_frame(video_decode_handle_id, &frame) == 0)
		{
			count = 0;
			// printf("%s ====================>>%d\n\r",__func__,__LINE__);
			if (frame_skip_count)
			{
				frame_skip_count--;
			}
			else
			{
				video_raw_push(frame.frame_obj.data.data, 0, frame.width, frame.height, frame.frame_obj.data.pitch_width, frame.frame_obj.data.pitch_height); //,frame.width,frame.height);
			}

			ak_vdec_release_frame(video_decode_handle_id, &frame);
			//视频稳定的标志位
			if (video_normal_falg == false)
			{
				video_normal_falg = true;
			}
		}
		else if ((count++) > 100)
		{
			int status = 0;
			ak_vdec_get_decode_finish(video_decode_handle_id, &status);

			if (status)
			{
				break;
			}
		}
		ak_sleep_ms(1);
	}
	video_raw_release_all();
	video_normal_falg = false;
	printf("===========<<< video h264 stream stop  >>>===========\n");
	ak_thread_exit();
	return NULL;
}

static void *video_decode_task(void *arg)
{
	video_decode_thread_run = true;

	video_decode_device_open();

	ak_pthread_t stream_thread_id;
	ak_thread_create(&stream_thread_id, video_decode_thread_task, NULL, ANYKA_THREAD_NORMAL_STACK_SIZE, -1);

	char *buffer = ak_mem_alloc(MODULE_ID_VDEC, 100 * 1024);
	int read_len = 0;

	video_decode_ready = true;
	while (video_decode_run == true)
	{
		read_len = ring_buffer_read(&video_decode_ring_buffer, buffer, 100 * 1024);
		if (read_len > 0)
		{
			// printf("%s ====================>>%d\n\r",__func__,__LINE__);
			video_data_stream_send((unsigned char *)buffer, read_len);
			ak_sleep_ms(1);
		}
		else
		{
			ak_sleep_ms(10);
		}
	}
	video_decode_ready = false;

	ak_mem_free(buffer);

	ak_vdec_end_stream(video_decode_handle_id);

	ak_thread_join(stream_thread_id);

	video_decode_device_close();

	video_decode_thread_run = false;

	video_normal_falg = false;
	printf("===========<<<video h264 decode close finish >>>===========\n");
	ak_thread_exit();
	return NULL;
}

static bool video_decode_wait_thread_quit(void)
{
	int timeout = 300;
	while (timeout--)
	{
		if (video_decode_thread_run == false)
		{
			return true;
		}
		usleep(10 * 1000);
	}
	return false;
}

bool video_decode_open(char type, int src_width, int src_height)
{
	if (video_decode_run == true)
	{
		printf("video decode open after \n");
		return false;
	}

	if (video_decode_wait_thread_quit() == false) //等待线程退出
	{
		printf("video decode thread wait error \n");
		return false;
	}

	decode_src_width = src_width;
	decode_src_height = src_height;
	video_decode_type = type;

	video_decode_ready = false;
	video_decode_run = true;
	ak_pthread_t video_decode_thread = 0;
	ak_thread_create(&video_decode_thread, video_decode_task, NULL, ANYKA_THREAD_NORMAL_STACK_SIZE, -1);
	ak_thread_detach(video_decode_thread);

	return true;
}

bool video_decode_resolution_contrast(int src_width, int src_height)
{
	if (decode_src_width != src_width || decode_src_height != src_height)
		return false;

	return true;
}

void video_decode_init(void)
{
	ak_thread_mutex_init(&video_decode_mutex, NULL);
}

bool video_decode_close(void)
{
	if (video_decode_run == false)
	{
		return false;
	}
	video_decode_run = false;
	return true;
}

bool video_decode_push(char type, unsigned char *data, int len)
{
	if ((video_decode_run == false) || (video_decode_ready == false))
	{
		return false;
	}

	if (type != video_decode_type)
	{
		return false;
	}
	ring_buffer_write(&video_decode_ring_buffer, (char *)data, len);
	return true;
}

bool video_decode_queue_reset(void)
{
	if ((video_decode_run == false) || (video_decode_ready == false))
	{
		return false;
	}

	video_normal_falg = false;
	ring_buffer_release(&video_decode_ring_buffer);
	ak_vdec_clear_buff(video_decode_handle_id); //在解码清除缓存时不一定清除完全，也许存留些帧作参考，因此下次显示时需要跳过残留帧
	video_raw_release_all();
	ring_buffer_init(&video_decode_ring_buffer, 200 * 1024, &video_decode_mutex);

	extern void frame_skip_count_set(int count);
	frame_skip_count_set(2); //下次显示跳过两帧

	printf("%s ====================>>%d\n\r", __func__, __LINE__);
	return true;
}

bool get_video_data_display_state(void)
{

	return video_normal_falg;
}
